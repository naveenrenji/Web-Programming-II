const recipesData = require('./recipes');
const usersData = require('./users');

module.exports = {
  recipes: recipesData,
  users: usersData
};